<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('trueman_sc_quote_theme_setup')) {
	add_action( 'trueman_action_before_init_theme', 'trueman_sc_quote_theme_setup' );
	function trueman_sc_quote_theme_setup() {
		add_action('trueman_action_shortcodes_list', 		'trueman_sc_quote_reg_shortcodes');
		if (function_exists('trueman_exists_visual_composer') && trueman_exists_visual_composer())
			add_action('trueman_action_shortcodes_list_vc','trueman_sc_quote_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_quote id="unique_id" cite="url" title=""]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/quote]
*/

if (!function_exists('trueman_sc_quote')) {	
	function trueman_sc_quote($atts, $content=null){	
		if (trueman_in_shortcode_blogger()) return '';
		extract(trueman_html_decode(shortcode_atts(array(
			// Individual params
			"title" => "",
			"cite" => "",
            "hide_padding" => "",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"width" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . trueman_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= trueman_get_css_dimensions_from_values($width);
		$cite_param = $cite != '' ? ' cite="'.esc_attr($cite).'"' : '';
		$title = $title=='' ? $cite : $title;
		$content = do_shortcode($content);
		if (trueman_substr($content, 0, 2)!='<p') $content = '<p>' . ($content) . '</p>';
		$output = '<blockquote' 
			. ($id ? ' id="'.esc_attr($id).'"' : '') . ($cite_param) 
			. ' class="sc_quote'. (!empty($class) ? ' '.esc_attr($class) : '')
            . ($hide_padding == 'yes' ? ' sc_quote_no_padding' : '')
            .'"'
			. (!trueman_param_is_off($animation) ? ' data-animation="'.esc_attr(trueman_get_animation_classes($animation)).'"' : '')
			. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
			. '>'
				. ($content)
				. ($title == '' ? '' : ('<p class="sc_quote_title">' . ($cite!='' ? '<a href="'.esc_url($cite).'">' : '') . ($title) . ($cite!='' ? '</a>' : '') . '</p>'))
			.'</blockquote>';
		return apply_filters('trueman_shortcode_output', $output, 'trx_quote', $atts, $content);
	}
	trueman_require_shortcode('trx_quote', 'trueman_sc_quote');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_quote_reg_shortcodes' ) ) {
	//add_action('trueman_action_shortcodes_list', 'trueman_sc_quote_reg_shortcodes');
	function trueman_sc_quote_reg_shortcodes() {
	
		trueman_sc_map("trx_quote", array(
			"title" => esc_html__("Quote", 'trueman'),
			"desc" => wp_kses_data( __("Quote text", 'trueman') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"cite" => array(
					"title" => esc_html__("Quote cite", 'trueman'),
					"desc" => wp_kses_data( __("URL for quote cite", 'trueman') ),
					"value" => "",
					"type" => "text"
				),
				"title" => array(
					"title" => esc_html__("Title (author)", 'trueman'),
					"desc" => wp_kses_data( __("Quote title (author name)", 'trueman') ),
					"value" => "",
					"type" => "text"
				),
                "hide_padding" => array(
                    "title" => esc_html__("Hide padding", 'trueman'),
                    "desc" => wp_kses_data( __("Hide quote padding", 'trueman') ),
                    "value" => "no",
                    "type" => "switch",
                    "options" => trueman_get_sc_param('yes_no')
                ),
				"_content_" => array(
					"title" => esc_html__("Quote content", 'trueman'),
					"desc" => wp_kses_data( __("Quote content", 'trueman') ),
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"width" => trueman_shortcodes_width(),
				"top" => trueman_get_sc_param('top'),
				"bottom" => trueman_get_sc_param('bottom'),
				"left" => trueman_get_sc_param('left'),
				"right" => trueman_get_sc_param('right'),
				"id" => trueman_get_sc_param('id'),
				"class" => trueman_get_sc_param('class'),
				"animation" => trueman_get_sc_param('animation'),
				"css" => trueman_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_quote_reg_shortcodes_vc' ) ) {
	//add_action('trueman_action_shortcodes_list_vc', 'trueman_sc_quote_reg_shortcodes_vc');
	function trueman_sc_quote_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_quote",
			"name" => esc_html__("Quote", 'trueman'),
			"description" => wp_kses_data( __("Quote text", 'trueman') ),
			"category" => esc_html__('Content', 'trueman'),
			'icon' => 'icon_trx_quote',
			"class" => "trx_sc_single trx_sc_quote",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "cite",
					"heading" => esc_html__("Quote cite", 'trueman'),
					"description" => wp_kses_data( __("URL for the quote cite link", 'trueman') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title (author)", 'trueman'),
					"description" => wp_kses_data( __("Quote title (author name)", 'trueman') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
                array(
                    "param_name" => "hide_padding",
                    "heading" => esc_html__("Hide paddings", 'trueman'),
                    "description" => wp_kses_data( __("Hide quote paddings", 'trueman') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => array(esc_html__('Hide quote paddings', 'trueman') => 'yes'),
                    "type" => "checkbox"
                ),
				array(
					"param_name" => "content",
					"heading" => esc_html__("Quote content", 'trueman'),
					"description" => wp_kses_data( __("Quote content", 'trueman') ),
					"class" => "",
					"value" => "",
					"type" => "textarea_html"
				),
				trueman_get_vc_param('id'),
				trueman_get_vc_param('class'),
				trueman_get_vc_param('animation'),
				trueman_get_vc_param('css'),
				trueman_vc_width(),
				trueman_get_vc_param('margin_top'),
				trueman_get_vc_param('margin_bottom'),
				trueman_get_vc_param('margin_left'),
				trueman_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextView'
		) );
		
		class WPBakeryShortCode_Trx_Quote extends TRUEMAN_VC_ShortCodeSingle {}
	}
}
?>