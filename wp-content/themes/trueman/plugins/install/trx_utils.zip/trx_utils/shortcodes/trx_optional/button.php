<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('trueman_sc_button_theme_setup')) {
	add_action( 'trueman_action_before_init_theme', 'trueman_sc_button_theme_setup' );
	function trueman_sc_button_theme_setup() {
		add_action('trueman_action_shortcodes_list', 		'trueman_sc_button_reg_shortcodes');
		if (function_exists('trueman_exists_visual_composer') && trueman_exists_visual_composer())
			add_action('trueman_action_shortcodes_list_vc','trueman_sc_button_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_button id="unique_id" type="square|round" fullsize="0|1" style="global|light|dark" size="mini|medium|big|huge|banner" icon="icon-name" link='#' target='']Button caption[/trx_button]
*/

if (!function_exists('trueman_sc_button')) {	
	function trueman_sc_button($atts, $content=null){	
		if (trueman_in_shortcode_blogger()) return '';
		extract(trueman_html_decode(shortcode_atts(array(
			// Individual params
			"type" => "square",
			"style" => "filled",
            "hoverstyle" => "filled",
			"size" => "small",
			"icon" => "",
			"color" => "",
			"bg_color" => "",
			"link" => "",
			"target" => "",
			"align" => "",
			"rel" => "",
			"popup" => "no",
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"animation" => "",
			"width" => "",
			"height" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . trueman_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= trueman_get_css_dimensions_from_values($width, $height)
			. ($color !== '' ? 'color:' . esc_attr($color) .';' : '')
			. ($bg_color !== '' ? 'background-color:' . esc_attr($bg_color) . '; border-color:'. esc_attr($bg_color) .';' : '');
		if (trueman_param_is_on($popup)) trueman_enqueue_popup('magnific');
		$output = '<a href="' . (empty($link) ? '#' : $link) . '"'
			. (!empty($target) ? ' target="'.esc_attr($target).'"' : '')
			. (!empty($rel) ? ' rel="'.esc_attr($rel).'"' : '')
			. (!trueman_param_is_off($animation) ? ' data-animation="'.esc_attr(trueman_get_animation_classes($animation)).'"' : '')
			. ' class="sc_button sc_button_' . esc_attr($type) 
					. ' sc_button_style_' . esc_attr($style) 
					. ' sc_button_hoverstyle_' . esc_attr($hoverstyle)
					. ' sc_button_size_' . esc_attr($size)
					. ($align && $align!='none' ? ' align'.esc_attr($align) : '') 
					. (!empty($class) ? ' '.esc_attr($class) : '')
					. ($icon!='' ? '  sc_button_iconed '. esc_attr($icon) : '') 
					. (trueman_param_is_on($popup) ? ' sc_popup_link' : '') 
					. '"'
			. ($id ? ' id="'.esc_attr($id).'"' : '') 
			. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
			. '>'
			. do_shortcode($content)
			. '</a>';
		return apply_filters('trueman_shortcode_output', $output, 'trx_button', $atts, $content);
	}
	trueman_require_shortcode('trx_button', 'trueman_sc_button');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_button_reg_shortcodes' ) ) {
	//add_action('trueman_action_shortcodes_list', 'trueman_sc_button_reg_shortcodes');
	function trueman_sc_button_reg_shortcodes() {
	
		trueman_sc_map("trx_button", array(
			"title" => esc_html__("Button", 'trueman'),
			"desc" => wp_kses_data( __("Button with link", 'trueman') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"_content_" => array(
					"title" => esc_html__("Caption", 'trueman'),
					"desc" => wp_kses_data( __("Button caption", 'trueman') ),
					"value" => "",
					"type" => "text"
				),
				"type" => array(
					"title" => esc_html__("Button's shape", 'trueman'),
					"desc" => wp_kses_data( __("Select button's shape", 'trueman') ),
					"value" => "square",
					"size" => "medium",
					"options" => array(
						'square' => esc_html__('Square', 'trueman'),
						'round' => esc_html__('Round', 'trueman')
					),
					"type" => "switch"
				), 
				"style" => array(
					"title" => esc_html__("Button's style", 'trueman'),
					"desc" => wp_kses_data( __("Select button's style", 'trueman') ),
					"value" => "default",
					"dir" => "horizontal",
					"options" => array(
						'filled' => esc_html__('Filled', 'trueman'),
						'border' => esc_html__('Border', 'trueman')
					),
					"type" => "checklist"
				),
                "hoverstyle" => array(
                    "title" => esc_html__("Button's hover style", 'trueman'),
                    "desc" => wp_kses_data( __("Select button's hover style", 'trueman') ),
                    "value" => "default",
                    "dir" => "horizontal",
                    "options" => array(
                        'filled' => esc_html__('Filled', 'trueman'),
                        'border' => esc_html__('Border', 'trueman')
                    ),
                    "type" => "checklist"
                ),
                "size" => array(
					"title" => esc_html__("Button's size", 'trueman'),
					"desc" => wp_kses_data( __("Select button's size", 'trueman') ),
					"value" => "small",
					"dir" => "horizontal",
					"options" => array(
						'small' => esc_html__('Small', 'trueman'),
						'medium' => esc_html__('Medium', 'trueman'),
						'large' => esc_html__('Large', 'trueman')
					),
					"type" => "checklist"
				), 
				"icon" => array(
					"title" => esc_html__("Button's icon",  'trueman'),
					"desc" => wp_kses_data( __('Select icon for the title from Fontello icons set',  'trueman') ),
					"value" => "",
					"type" => "icons",
					"options" => trueman_get_sc_param('icons')
				),
				"color" => array(
					"title" => esc_html__("Button's text color", 'trueman'),
					"desc" => wp_kses_data( __("Any color for button's caption", 'trueman') ),
					"std" => "",
					"value" => "",
					"type" => "color"
				),
				"bg_color" => array(
					"title" => esc_html__("Button's backcolor", 'trueman'),
					"desc" => wp_kses_data( __("Any color for button's background", 'trueman') ),
					"value" => "",
					"type" => "color"
				),
				"align" => array(
					"title" => esc_html__("Button's alignment", 'trueman'),
					"desc" => wp_kses_data( __("Align button to left, center or right", 'trueman') ),
					"value" => "none",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => trueman_get_sc_param('align')
				), 
				"link" => array(
					"title" => esc_html__("Link URL", 'trueman'),
					"desc" => wp_kses_data( __("URL for link on button click", 'trueman') ),
					"divider" => true,
					"value" => "",
					"type" => "text"
				),
				"target" => array(
					"title" => esc_html__("Link target", 'trueman'),
					"desc" => wp_kses_data( __("Target for link on button click", 'trueman') ),
					"dependency" => array(
						'link' => array('not_empty')
					),
					"value" => "",
					"type" => "text"
				),
				"popup" => array(
					"title" => esc_html__("Open link in popup", 'trueman'),
					"desc" => wp_kses_data( __("Open link target in popup window", 'trueman') ),
					"dependency" => array(
						'link' => array('not_empty')
					),
					"value" => "no",
					"type" => "switch",
					"options" => trueman_get_sc_param('yes_no')
				), 
				"rel" => array(
					"title" => esc_html__("Rel attribute", 'trueman'),
					"desc" => wp_kses_data( __("Rel attribute for button's link (if need)", 'trueman') ),
					"dependency" => array(
						'link' => array('not_empty')
					),
					"value" => "",
					"type" => "text"
				),
				"width" => trueman_shortcodes_width(),
				"height" => trueman_shortcodes_height(),
				"top" => trueman_get_sc_param('top'),
				"bottom" => trueman_get_sc_param('bottom'),
				"left" => trueman_get_sc_param('left'),
				"right" => trueman_get_sc_param('right'),
				"id" => trueman_get_sc_param('id'),
				"class" => trueman_get_sc_param('class'),
				"animation" => trueman_get_sc_param('animation'),
				"css" => trueman_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_button_reg_shortcodes_vc' ) ) {
	//add_action('trueman_action_shortcodes_list_vc', 'trueman_sc_button_reg_shortcodes_vc');
	function trueman_sc_button_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_button",
			"name" => esc_html__("Button", 'trueman'),
			"description" => wp_kses_data( __("Button with link", 'trueman') ),
			"category" => esc_html__('Content', 'trueman'),
			'icon' => 'icon_trx_button',
			"class" => "trx_sc_single trx_sc_button",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "content",
					"heading" => esc_html__("Caption", 'trueman'),
					"description" => wp_kses_data( __("Button caption", 'trueman') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "type",
					"heading" => esc_html__("Button's shape", 'trueman'),
					"description" => wp_kses_data( __("Select button's shape", 'trueman') ),
					"class" => "",
					"value" => array(
						esc_html__('Square', 'trueman') => 'square',
						esc_html__('Round', 'trueman') => 'round'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "style",
					"heading" => esc_html__("Button's style", 'trueman'),
					"description" => wp_kses_data( __("Select button's style", 'trueman') ),
					"class" => "",
					"value" => array(
						esc_html__('Filled', 'trueman') => 'filled',
						esc_html__('Border', 'trueman') => 'border'
					),
					"type" => "dropdown"
				),
                array(
                    "param_name" => "hoverstyle",
                    "heading" => esc_html__("Button's hover style", 'trueman'),
                    "description" => wp_kses_data( __("Select button's hover style", 'trueman') ),
                    "class" => "",
                    "value" => array(
                        esc_html__('Filled', 'trueman') => 'filled',
                        esc_html__('Border', 'trueman') => 'border'
                    ),
                    "type" => "dropdown"
                ),
				array(
					"param_name" => "size",
					"heading" => esc_html__("Button's size", 'trueman'),
					"description" => wp_kses_data( __("Select button's size", 'trueman') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Small', 'trueman') => 'small',
						esc_html__('Medium', 'trueman') => 'medium',
						esc_html__('Large', 'trueman') => 'large'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Button's icon", 'trueman'),
					"description" => wp_kses_data( __("Select icon for the title from Fontello icons set", 'trueman') ),
					"class" => "",
					"value" => trueman_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "color",
					"heading" => esc_html__("Button's text color", 'trueman'),
					"description" => wp_kses_data( __("Any color for button's caption", 'trueman') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "bg_color",
					"heading" => esc_html__("Button's backcolor", 'trueman'),
					"description" => wp_kses_data( __("Any color for button's background", 'trueman') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Button's alignment", 'trueman'),
					"description" => wp_kses_data( __("Align button to left, center or right", 'trueman') ),
					"class" => "",
					"value" => array_flip(trueman_get_sc_param('align')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "link",
					"heading" => esc_html__("Link URL", 'trueman'),
					"description" => wp_kses_data( __("URL for the link on button click", 'trueman') ),
					"class" => "",
					"group" => esc_html__('Link', 'trueman'),
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "target",
					"heading" => esc_html__("Link target", 'trueman'),
					"description" => wp_kses_data( __("Target for the link on button click", 'trueman') ),
					"class" => "",
					"group" => esc_html__('Link', 'trueman'),
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "popup",
					"heading" => esc_html__("Open link in popup", 'trueman'),
					"description" => wp_kses_data( __("Open link target in popup window", 'trueman') ),
					"class" => "",
					"group" => esc_html__('Link', 'trueman'),
					"value" => array(esc_html__('Open in popup', 'trueman') => 'yes'),
					"type" => "checkbox"
				),
				array(
					"param_name" => "rel",
					"heading" => esc_html__("Rel attribute", 'trueman'),
					"description" => wp_kses_data( __("Rel attribute for the button's link (if need", 'trueman') ),
					"class" => "",
					"group" => esc_html__('Link', 'trueman'),
					"value" => "",
					"type" => "textfield"
				),
				trueman_get_vc_param('id'),
				trueman_get_vc_param('class'),
				trueman_get_vc_param('animation'),
				trueman_get_vc_param('css'),
				trueman_vc_width(),
				trueman_vc_height(),
				trueman_get_vc_param('margin_top'),
				trueman_get_vc_param('margin_bottom'),
				trueman_get_vc_param('margin_left'),
				trueman_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextView'
		) );
		
		class WPBakeryShortCode_Trx_Button extends TRUEMAN_VC_ShortCodeSingle {}
	}
}
?>