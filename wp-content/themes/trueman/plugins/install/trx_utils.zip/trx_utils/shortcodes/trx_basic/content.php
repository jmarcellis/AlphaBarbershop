<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('trueman_sc_content_theme_setup')) {
	add_action( 'trueman_action_before_init_theme', 'trueman_sc_content_theme_setup' );
	function trueman_sc_content_theme_setup() {
		add_action('trueman_action_shortcodes_list', 		'trueman_sc_content_reg_shortcodes');
		if (function_exists('trueman_exists_visual_composer') && trueman_exists_visual_composer())
			add_action('trueman_action_shortcodes_list_vc','trueman_sc_content_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_content id="unique_id" class="class_name" style="css-styles"]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_content]
*/

if (!function_exists('trueman_sc_content')) {	
	function trueman_sc_content($atts, $content=null){	
		if (trueman_in_shortcode_blogger()) return '';
		extract(trueman_html_decode(shortcode_atts(array(
			"scheme" => "",
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"animation" => "",
			"top" => "",
			"bottom" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . trueman_get_css_position_as_classes($top, '', $bottom);
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
			. ' class="sc_content content_wrap' 
				. ($scheme && !trueman_param_is_off($scheme) && !trueman_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '') 
				. ($class ? ' '.esc_attr($class) : '') 
				. '"'
			. (!trueman_param_is_off($animation) ? ' data-animation="'.esc_attr(trueman_get_animation_classes($animation)).'"' : '')
			. ($css!='' ? ' style="'.esc_attr($css).'"' : '').'>' 
			. do_shortcode($content) 
			. '</div>';
		return apply_filters('trueman_shortcode_output', $output, 'trx_content', $atts, $content);
	}
	trueman_require_shortcode('trx_content', 'trueman_sc_content');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_content_reg_shortcodes' ) ) {
	//add_action('trueman_action_shortcodes_list', 'trueman_sc_content_reg_shortcodes');
	function trueman_sc_content_reg_shortcodes() {
	
		trueman_sc_map("trx_content", array(
			"title" => esc_html__("Content block", 'trueman'),
			"desc" => wp_kses_data( __("Container for main content block with desired class and style (use it only on fullscreen pages)", 'trueman') ),
			"decorate" => true,
			"container" => true,
			"params" => array(
				"scheme" => array(
					"title" => esc_html__("Color scheme", 'trueman'),
					"desc" => wp_kses_data( __("Select color scheme for this block", 'trueman') ),
					"value" => "",
					"type" => "checklist",
					"options" => trueman_get_sc_param('schemes')
				),
				"_content_" => array(
					"title" => esc_html__("Container content", 'trueman'),
					"desc" => wp_kses_data( __("Content for section container", 'trueman') ),
					"divider" => true,
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"top" => trueman_get_sc_param('top'),
				"bottom" => trueman_get_sc_param('bottom'),
				"id" => trueman_get_sc_param('id'),
				"class" => trueman_get_sc_param('class'),
				"animation" => trueman_get_sc_param('animation'),
				"css" => trueman_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_content_reg_shortcodes_vc' ) ) {
	//add_action('trueman_action_shortcodes_list_vc', 'trueman_sc_content_reg_shortcodes_vc');
	function trueman_sc_content_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_content",
			"name" => esc_html__("Content block", 'trueman'),
			"description" => wp_kses_data( __("Container for main content block (use it only on fullscreen pages)", 'trueman') ),
			"category" => esc_html__('Content', 'trueman'),
			'icon' => 'icon_trx_content',
			"class" => "trx_sc_collection trx_sc_content",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "scheme",
					"heading" => esc_html__("Color scheme", 'trueman'),
					"description" => wp_kses_data( __("Select color scheme for this block", 'trueman') ),
					"group" => esc_html__('Colors and Images', 'trueman'),
					"class" => "",
					"value" => array_flip(trueman_get_sc_param('schemes')),
					"type" => "dropdown"
				),
				trueman_get_vc_param('id'),
				trueman_get_vc_param('class'),
				trueman_get_vc_param('animation'),
				trueman_get_vc_param('css'),
				trueman_get_vc_param('margin_top'),
				trueman_get_vc_param('margin_bottom')
			)
		) );
		
		class WPBakeryShortCode_Trx_Content extends TRUEMAN_VC_ShortCodeCollection {}
	}
}
?>