<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('trueman_sc_countdown_theme_setup')) {
	add_action( 'trueman_action_before_init_theme', 'trueman_sc_countdown_theme_setup' );
	function trueman_sc_countdown_theme_setup() {
		add_action('trueman_action_shortcodes_list', 		'trueman_sc_countdown_reg_shortcodes');
		if (function_exists('trueman_exists_visual_composer') && trueman_exists_visual_composer())
			add_action('trueman_action_shortcodes_list_vc','trueman_sc_countdown_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

//[trx_countdown date="" time=""]

if (!function_exists('trueman_sc_countdown')) {	
	function trueman_sc_countdown($atts, $content = null) {
		if (trueman_in_shortcode_blogger()) return '';
		extract(trueman_html_decode(shortcode_atts(array(
			// Individual params
			"date" => "",
			"time" => "",
			"style" => "1",
			"align" => "center",
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"animation" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => "",
			"width" => "",
			"height" => ""
		), $atts)));
		if (empty($id)) $id = "sc_countdown_".str_replace('.', '', mt_rand());
		$class .= ($class ? ' ' : '') . trueman_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= trueman_get_css_dimensions_from_values($width, $height);
		if (empty($interval)) $interval = 1;
		wp_enqueue_script( 'trueman-jquery-plugin-script', trueman_get_file_url('js/countdown/jquery.plugin.js'), array('jquery'), null, true );
		wp_enqueue_script( 'trueman-countdown-script', trueman_get_file_url('js/countdown/jquery.countdown.js'), array('jquery'), null, true );
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
			. ' class="sc_countdown sc_countdown_style_' . esc_attr(max(1, min(2, $style))) . (!empty($align) && $align!='none' ? ' align'.esc_attr($align) : '') . (!empty($class) ? ' '.esc_attr($class) : '') .'"'
			. ($css ? ' style="'.esc_attr($css).'"' : '')
			. ' data-date="'.esc_attr(empty($date) ? date('Y-m-d') : $date).'"'
			. ' data-time="'.esc_attr(empty($time) ? '00:00:00' : $time).'"'
			. (!trueman_param_is_off($animation) ? ' data-animation="'.esc_attr(trueman_get_animation_classes($animation)).'"' : '')
			. '>'
				. ($align=='center' ? '<div class="sc_countdown_inner">' : '')
				. '<div class="sc_countdown_item sc_countdown_days">'
					. '<span class="sc_countdown_digits"><span></span><span></span><span></span></span>'
					. '<span class="sc_countdown_label">'.esc_html__('Days', 'trueman').'</span>'
				. '</div>'
				. '<div class="sc_countdown_separator"></div>'
				. '<div class="sc_countdown_item sc_countdown_hours">'
					. '<span class="sc_countdown_digits"><span></span><span></span></span>'
					. '<span class="sc_countdown_label">'.esc_html__('Hours', 'trueman').'</span>'
				. '</div>'
				. '<div class="sc_countdown_separator"></div>'
				. '<div class="sc_countdown_item sc_countdown_minutes">'
					. '<span class="sc_countdown_digits"><span></span><span></span></span>'
					. '<span class="sc_countdown_label">'.esc_html__('Minutes', 'trueman').'</span>'
				. '</div>'
				. '<div class="sc_countdown_separator"></div>'
				. '<div class="sc_countdown_item sc_countdown_seconds">'
					. '<span class="sc_countdown_digits"><span></span><span></span></span>'
					. '<span class="sc_countdown_label">'.esc_html__('Seconds', 'trueman').'</span>'
				. '</div>'
				. '<div class="sc_countdown_placeholder hide"></div>'
				. ($align=='center' ? '</div>' : '')
			. '</div>';
		return apply_filters('trueman_shortcode_output', $output, 'trx_countdown', $atts, $content);
	}
	trueman_require_shortcode("trx_countdown", "trueman_sc_countdown");
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_countdown_reg_shortcodes' ) ) {
	//add_action('trueman_action_shortcodes_list', 'trueman_sc_countdown_reg_shortcodes');
	function trueman_sc_countdown_reg_shortcodes() {
	
		trueman_sc_map("trx_countdown", array(
			"title" => esc_html__("Countdown", 'trueman'),
			"desc" => wp_kses_data( __("Insert countdown object", 'trueman') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"date" => array(
					"title" => esc_html__("Date", 'trueman'),
					"desc" => wp_kses_data( __("Upcoming date (format: yyyy-mm-dd)", 'trueman') ),
					"value" => "",
					"format" => "yy-mm-dd",
					"type" => "date"
				),
				"time" => array(
					"title" => esc_html__("Time", 'trueman'),
					"desc" => wp_kses_data( __("Upcoming time (format: HH:mm:ss)", 'trueman') ),
					"value" => "",
					"type" => "text"
				),
				"style" => array(
					"title" => esc_html__("Style", 'trueman'),
					"desc" => wp_kses_data( __("Countdown style", 'trueman') ),
					"value" => "1",
					"type" => "checklist",
					"options" => trueman_get_list_styles(1, 2)
				),
				"align" => array(
					"title" => esc_html__("Alignment", 'trueman'),
					"desc" => wp_kses_data( __("Align counter to left, center or right", 'trueman') ),
					"divider" => true,
					"value" => "none",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => trueman_get_sc_param('align')
				), 
				"width" => trueman_shortcodes_width(),
				"height" => trueman_shortcodes_height(),
				"top" => trueman_get_sc_param('top'),
				"bottom" => trueman_get_sc_param('bottom'),
				"left" => trueman_get_sc_param('left'),
				"right" => trueman_get_sc_param('right'),
				"id" => trueman_get_sc_param('id'),
				"class" => trueman_get_sc_param('class'),
				"animation" => trueman_get_sc_param('animation'),
				"css" => trueman_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_countdown_reg_shortcodes_vc' ) ) {
	//add_action('trueman_action_shortcodes_list_vc', 'trueman_sc_countdown_reg_shortcodes_vc');
	function trueman_sc_countdown_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_countdown",
			"name" => esc_html__("Countdown", 'trueman'),
			"description" => wp_kses_data( __("Insert countdown object", 'trueman') ),
			"category" => esc_html__('Content', 'trueman'),
			'icon' => 'icon_trx_countdown',
			"class" => "trx_sc_single trx_sc_countdown",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "date",
					"heading" => esc_html__("Date", 'trueman'),
					"description" => wp_kses_data( __("Upcoming date (format: yyyy-mm-dd)", 'trueman') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "time",
					"heading" => esc_html__("Time", 'trueman'),
					"description" => wp_kses_data( __("Upcoming time (format: HH:mm:ss)", 'trueman') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "style",
					"heading" => esc_html__("Style", 'trueman'),
					"description" => wp_kses_data( __("Countdown style", 'trueman') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(trueman_get_list_styles(1, 2)),
					"type" => "dropdown"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'trueman'),
					"description" => wp_kses_data( __("Align counter to left, center or right", 'trueman') ),
					"class" => "",
					"value" => array_flip(trueman_get_sc_param('align')),
					"type" => "dropdown"
				),
				trueman_get_vc_param('id'),
				trueman_get_vc_param('class'),
				trueman_get_vc_param('animation'),
				trueman_get_vc_param('css'),
				trueman_vc_width(),
				trueman_vc_height(),
				trueman_get_vc_param('margin_top'),
				trueman_get_vc_param('margin_bottom'),
				trueman_get_vc_param('margin_left'),
				trueman_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Countdown extends TRUEMAN_VC_ShortCodeSingle {}
	}
}
?>