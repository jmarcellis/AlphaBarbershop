<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('trueman_sc_toggles_theme_setup')) {
	add_action( 'trueman_action_before_init_theme', 'trueman_sc_toggles_theme_setup' );
	function trueman_sc_toggles_theme_setup() {
		add_action('trueman_action_shortcodes_list', 		'trueman_sc_toggles_reg_shortcodes');
		if (function_exists('trueman_exists_visual_composer') && trueman_exists_visual_composer())
			add_action('trueman_action_shortcodes_list_vc','trueman_sc_toggles_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

if (!function_exists('trueman_sc_toggles')) {	
	function trueman_sc_toggles($atts, $content=null){	
		if (trueman_in_shortcode_blogger()) return '';
		extract(trueman_html_decode(shortcode_atts(array(
			// Individual params
			"counter" => "off",
			"icon_closed" => "icon-plus",
			"icon_opened" => "icon-minus",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . trueman_get_css_position_as_classes($top, $right, $bottom, $left);
		trueman_storage_set('sc_toggle_data', array(
			'counter' => 0,
            'show_counter' => trueman_param_is_on($counter),
            'icon_closed' => empty($icon_closed) || trueman_param_is_inherit($icon_closed) ? "icon-plus" : $icon_closed,
            'icon_opened' => empty($icon_opened) || trueman_param_is_inherit($icon_opened) ? "icon-minus" : $icon_opened
            )
        );
		wp_enqueue_script('jquery-effects-slide', false, array('jquery','jquery-effects-core'), null, true);
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
				. ' class="sc_toggles'
					. (!empty($class) ? ' '.esc_attr($class) : '')
					. (trueman_param_is_on($counter) ? ' sc_show_counter' : '') 
					. '"'
				. (!trueman_param_is_off($animation) ? ' data-animation="'.esc_attr(trueman_get_animation_classes($animation)).'"' : '')
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
				. '>'
				. do_shortcode($content)
				. '</div>';
		return apply_filters('trueman_shortcode_output', $output, 'trx_toggles', $atts, $content);
	}
	trueman_require_shortcode('trx_toggles', 'trueman_sc_toggles');
}


if (!function_exists('trueman_sc_toggles_item')) {	
	function trueman_sc_toggles_item($atts, $content=null) {
		if (trueman_in_shortcode_blogger()) return '';
		extract(trueman_html_decode(shortcode_atts( array(
			// Individual params
			"title" => "",
			"open" => "",
			"icon_closed" => "",
			"icon_opened" => "",
			// Common params
			"id" => "",
			"class" => "",
			"css" => ""
		), $atts)));
		trueman_storage_inc_array('sc_toggle_data', 'counter');
		if (empty($icon_closed) || trueman_param_is_inherit($icon_closed)) $icon_closed = trueman_storage_get_array('sc_toggles_data', 'icon_closed', '', "icon-plus");
		if (empty($icon_opened) || trueman_param_is_inherit($icon_opened)) $icon_opened = trueman_storage_get_array('sc_toggles_data', 'icon_opened', '', "icon-minus");
		$css .= trueman_param_is_on($open) ? 'display:block;' : '';
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
					. ' class="sc_toggles_item'.(trueman_param_is_on($open) ? ' sc_active' : '')
					. (!empty($class) ? ' '.esc_attr($class) : '')
					. (trueman_storage_get_array('sc_toggle_data', 'counter') % 2 == 1 ? ' odd' : ' even') 
					. (trueman_storage_get_array('sc_toggle_data', 'counter') == 1 ? ' first' : '')
					. '">'
					. '<h5 class="sc_toggles_title'.(trueman_param_is_on($open) ? ' ui-state-active' : '').'">'
					. (!trueman_param_is_off($icon_closed) ? '<span class="sc_toggles_icon sc_toggles_icon_closed '.esc_attr($icon_closed).'"></span>' : '')
					. (!trueman_param_is_off($icon_opened) ? '<span class="sc_toggles_icon sc_toggles_icon_opened '.esc_attr($icon_opened).'"></span>' : '')
					. (trueman_storage_get_array('sc_toggle_data', 'show_counter') ? '<span class="sc_items_counter">'.(trueman_storage_get_array('sc_toggle_data', 'counter')).'</span>' : '')
					. ($title) 
					. '</h5>'
					. '<div class="sc_toggles_content"'
						. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
						.'>' 
						. do_shortcode($content) 
					. '</div>'
				. '</div>';
		return apply_filters('trueman_shortcode_output', $output, 'trx_toggles_item', $atts, $content);
	}
	trueman_require_shortcode('trx_toggles_item', 'trueman_sc_toggles_item');
}


/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_toggles_reg_shortcodes' ) ) {
	//add_action('trueman_action_shortcodes_list', 'trueman_sc_toggles_reg_shortcodes');
	function trueman_sc_toggles_reg_shortcodes() {
	
		trueman_sc_map("trx_toggles", array(
			"title" => esc_html__("Toggles", 'trueman'),
			"desc" => wp_kses_data( __("Toggles items", 'trueman') ),
			"decorate" => true,
			"container" => false,
			"params" => array(
				"counter" => array(
					"title" => esc_html__("Counter", 'trueman'),
					"desc" => wp_kses_data( __("Display counter before each toggles title", 'trueman') ),
					"value" => "off",
					"type" => "switch",
					"options" => trueman_get_sc_param('on_off')
				),
				"icon_closed" => array(
					"title" => esc_html__("Icon while closed",  'trueman'),
					"desc" => wp_kses_data( __('Select icon for the closed toggles item from Fontello icons set',  'trueman') ),
					"value" => "",
					"type" => "icons",
					"options" => trueman_get_sc_param('icons')
				),
				"icon_opened" => array(
					"title" => esc_html__("Icon while opened",  'trueman'),
					"desc" => wp_kses_data( __('Select icon for the opened toggles item from Fontello icons set',  'trueman') ),
					"value" => "",
					"type" => "icons",
					"options" => trueman_get_sc_param('icons')
				),
				"top" => trueman_get_sc_param('top'),
				"bottom" => trueman_get_sc_param('bottom'),
				"left" => trueman_get_sc_param('left'),
				"right" => trueman_get_sc_param('right'),
				"id" => trueman_get_sc_param('id'),
				"class" => trueman_get_sc_param('class'),
				"animation" => trueman_get_sc_param('animation'),
				"css" => trueman_get_sc_param('css')
			),
			"children" => array(
				"name" => "trx_toggles_item",
				"title" => esc_html__("Toggles item", 'trueman'),
				"desc" => wp_kses_data( __("Toggles item", 'trueman') ),
				"container" => true,
				"params" => array(
					"title" => array(
						"title" => esc_html__("Toggles item title", 'trueman'),
						"desc" => wp_kses_data( __("Title for current toggles item", 'trueman') ),
						"value" => "",
						"type" => "text"
					),
					"open" => array(
						"title" => esc_html__("Open on show", 'trueman'),
						"desc" => wp_kses_data( __("Open current toggles item on show", 'trueman') ),
						"value" => "no",
						"type" => "switch",
						"options" => trueman_get_sc_param('yes_no')
					),
					"icon_closed" => array(
						"title" => esc_html__("Icon while closed",  'trueman'),
						"desc" => wp_kses_data( __('Select icon for the closed toggles item from Fontello icons set',  'trueman') ),
						"value" => "",
						"type" => "icons",
						"options" => trueman_get_sc_param('icons')
					),
					"icon_opened" => array(
						"title" => esc_html__("Icon while opened",  'trueman'),
						"desc" => wp_kses_data( __('Select icon for the opened toggles item from Fontello icons set',  'trueman') ),
						"value" => "",
						"type" => "icons",
						"options" => trueman_get_sc_param('icons')
					),
					"_content_" => array(
						"title" => esc_html__("Toggles item content", 'trueman'),
						"desc" => wp_kses_data( __("Current toggles item content", 'trueman') ),
						"rows" => 4,
						"value" => "",
						"type" => "textarea"
					),
					"id" => trueman_get_sc_param('id'),
					"class" => trueman_get_sc_param('class'),
					"css" => trueman_get_sc_param('css')
				)
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_toggles_reg_shortcodes_vc' ) ) {
	//add_action('trueman_action_shortcodes_list_vc', 'trueman_sc_toggles_reg_shortcodes_vc');
	function trueman_sc_toggles_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_toggles",
			"name" => esc_html__("Toggles", 'trueman'),
			"description" => wp_kses_data( __("Toggles items", 'trueman') ),
			"category" => esc_html__('Content', 'trueman'),
			'icon' => 'icon_trx_toggles',
			"class" => "trx_sc_collection trx_sc_toggles",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => false,
			"as_parent" => array('only' => 'trx_toggles_item'),
			"params" => array(
				array(
					"param_name" => "counter",
					"heading" => esc_html__("Counter", 'trueman'),
					"description" => wp_kses_data( __("Display counter before each toggles title", 'trueman') ),
					"class" => "",
					"value" => array("Add item numbers before each element" => "on" ),
					"type" => "checkbox"
				),
				array(
					"param_name" => "icon_closed",
					"heading" => esc_html__("Icon while closed", 'trueman'),
					"description" => wp_kses_data( __("Select icon for the closed toggles item from Fontello icons set", 'trueman') ),
					"class" => "",
					"value" => trueman_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "icon_opened",
					"heading" => esc_html__("Icon while opened", 'trueman'),
					"description" => wp_kses_data( __("Select icon for the opened toggles item from Fontello icons set", 'trueman') ),
					"class" => "",
					"value" => trueman_get_sc_param('icons'),
					"type" => "dropdown"
				),
				trueman_get_vc_param('id'),
				trueman_get_vc_param('class'),
				trueman_get_vc_param('margin_top'),
				trueman_get_vc_param('margin_bottom'),
				trueman_get_vc_param('margin_left'),
				trueman_get_vc_param('margin_right')
			),
			'default_content' => '
				[trx_toggles_item title="' . esc_html__( 'Item 1 title', 'trueman' ) . '"][/trx_toggles_item]
				[trx_toggles_item title="' . esc_html__( 'Item 2 title', 'trueman' ) . '"][/trx_toggles_item]
			',
			"custom_markup" => '
				<div class="wpb_accordion_holder wpb_holder clearfix vc_container_for_children">
					%content%
				</div>
				<div class="tab_controls">
					<button class="add_tab" title="'.esc_attr__("Add item", 'trueman').'">'.esc_html__("Add item", 'trueman').'</button>
				</div>
			',
			'js_view' => 'VcTrxTogglesView'
		) );
		
		
		vc_map( array(
			"base" => "trx_toggles_item",
			"name" => esc_html__("Toggles item", 'trueman'),
			"description" => wp_kses_data( __("Single toggles item", 'trueman') ),
			"show_settings_on_create" => true,
			"content_element" => true,
			"is_container" => true,
			'icon' => 'icon_trx_toggles_item',
			"as_child" => array('only' => 'trx_toggles'),
			"as_parent" => array('except' => 'trx_toggles'),
			"params" => array(
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title", 'trueman'),
					"description" => wp_kses_data( __("Title for current toggles item", 'trueman') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "open",
					"heading" => esc_html__("Open on show", 'trueman'),
					"description" => wp_kses_data( __("Open current toggle item on show", 'trueman') ),
					"class" => "",
					"value" => array("Opened" => "yes" ),
					"type" => "checkbox"
				),
				array(
					"param_name" => "icon_closed",
					"heading" => esc_html__("Icon while closed", 'trueman'),
					"description" => wp_kses_data( __("Select icon for the closed toggles item from Fontello icons set", 'trueman') ),
					"class" => "",
					"value" => trueman_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "icon_opened",
					"heading" => esc_html__("Icon while opened", 'trueman'),
					"description" => wp_kses_data( __("Select icon for the opened toggles item from Fontello icons set", 'trueman') ),
					"class" => "",
					"value" => trueman_get_sc_param('icons'),
					"type" => "dropdown"
				),
				trueman_get_vc_param('id'),
				trueman_get_vc_param('class'),
				trueman_get_vc_param('css')
			),
			'js_view' => 'VcTrxTogglesTabView'
		) );
		class WPBakeryShortCode_Trx_Toggles extends TRUEMAN_VC_ShortCodeToggles {}
		class WPBakeryShortCode_Trx_Toggles_Item extends TRUEMAN_VC_ShortCodeTogglesItem {}
	}
}
?>