<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('trueman_sc_call_to_action_theme_setup')) {
	add_action( 'trueman_action_before_init_theme', 'trueman_sc_call_to_action_theme_setup' );
	function trueman_sc_call_to_action_theme_setup() {
		add_action('trueman_action_shortcodes_list', 		'trueman_sc_call_to_action_reg_shortcodes');
		if (function_exists('trueman_exists_visual_composer') && trueman_exists_visual_composer())
			add_action('trueman_action_shortcodes_list_vc','trueman_sc_call_to_action_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_call_to_action id="unique_id" style="1|2" align="left|center|right"]
	[inner shortcodes]
[/trx_call_to_action]
*/

if (!function_exists('trueman_sc_call_to_action')) {	
	function trueman_sc_call_to_action($atts, $content=null){	
		if (trueman_in_shortcode_blogger()) return '';
		extract(trueman_html_decode(shortcode_atts(array(
			// Individual params
			"style" => "1",
			"align" => "center",
			"custom" => "no",
			"accent" => "no",
			"image" => "",
			"video" => "",
			"title" => "",
			"subtitle" => "",
			"description" => "",
			"link" => '',
			"link_caption" => esc_html__('Learn more', 'trueman'),
			"link2" => '',
			"link2_caption" => '',
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"width" => "",
			"height" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
	
		if (empty($id)) $id = "sc_call_to_action_".str_replace('.', '', mt_rand());
		if (empty($width)) $width = "100%";

		if ($image > 0) {
			$attach = wp_get_attachment_image_src( $image, 'full' );
			if (isset($attach[0]) && $attach[0]!='')
				$image = $attach[0];
                $bg_image = $attach[0];
		}

		if (!empty($image)) {
			$thumb_sizes = trueman_get_thumb_sizes(array('layout' => 'excerpt'));
			$image = !empty($video)
				? trueman_get_resized_image_url($image, $thumb_sizes['w'], $thumb_sizes['h'])
				: trueman_get_resized_image_tag($image, $thumb_sizes['w'], $thumb_sizes['h']);
		}

		if (!empty($video)) {
			$video = '<video' . ($id ? ' id="' . esc_attr($id.'_video') . '"' : '') 
				. ' class="sc_video"'
				. ' src="' . esc_url(trueman_get_video_player_url($video)) . '"'
				. ' width="' . esc_attr($width) . '" height="' . esc_attr($height) . '"' 
				. ' data-width="' . esc_attr($width) . '" data-height="' . esc_attr($height) . '"' 
				. ' data-ratio="16:9"'
				. ($image ? ' poster="'.esc_attr($image).'" data-image="'.esc_attr($image).'"' : '')
				. ' controls="controls" loop="loop"'
				. '>'
				. '</video>';
			if (trueman_get_custom_option('substitute_video')=='no') {
				$video = trueman_get_video_frame($video, $image, '', '');
			} else {
				if ((isset($_GET['vc_editable']) && $_GET['vc_editable']=='true') && (isset($_POST['action']) && $_POST['action']=='vc_load_shortcode')) {
					$video = trueman_substitute_video($video, $width, $height, false);
				}
			}
			if (trueman_get_theme_option('use_mediaelement')=='yes')
				wp_enqueue_script('wp-mediaelement');
		}
		
		$class .= ($class ? ' ' : '') . trueman_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= trueman_get_css_dimensions_from_values($width, $height);
		$css .= ($bg_image !== '' ? 'background-image:url(' . esc_url($bg_image) . ');' : '');

		$content = do_shortcode($content);
		
		$need_columns = ($style==2) && !in_array($align, array('center', 'none'))
							? ($style==2 ? 4 : 2)
							: 0;
		
		$buttons = (!empty($link) || !empty($link2) 
						? '<div class="sc_call_to_action_buttons sc_item_buttons'.($need_columns && $style==2 ? ' column-1_'.esc_attr($need_columns) : '').'">'
							. (!empty($link) 
								? '<div class="sc_call_to_action_button sc_item_button">'.do_shortcode('[trx_button link="'.esc_url($link).'"]'.esc_html($link_caption).'[/trx_button]').'</div>'
								: '')
							. (!empty($link2) 
								? '<div class="sc_call_to_action_button sc_item_button">'.do_shortcode('[trx_button link="'.esc_url($link2).'"]'.esc_html($link2_caption).'[/trx_button]').'</div>'
								: '')
							. '</div>'
						: '');
	
		
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
				. ' class="sc_call_to_action'
					. (trueman_param_is_on($accent) ? ' sc_call_to_action_accented' : '')
					. ' sc_call_to_action_style_' . esc_attr($style)
					. ' sc_call_to_action_align_'.esc_attr($align)
					. (!empty($class) ? ' '.esc_attr($class) : '')
					. '"'
				. (!trueman_param_is_off($animation) ? ' data-animation="'.esc_attr(trueman_get_animation_classes($animation)).'"' : '')
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
			. '>'
				. ($need_columns ? '<div class="columns_wrap">' : '')
				. ($style==2 && $align=='right' ? $buttons : '')
				. '<div class="sc_call_to_action_info'.($need_columns ? ' column-'.esc_attr($need_columns-1).'_'.esc_attr($need_columns) : '').'">'
					. (!empty($subtitle) ? '<h6 class="sc_call_to_action_subtitle sc_item_subtitle">' . trim(trueman_strmacros($subtitle)) . '</h6>' : '')
					. (!empty($title) ? '<h2 class="sc_call_to_action_title sc_item_title">' . trim(trueman_strmacros($title)) . '</h2>' : '')
					. (!empty($description) ? '<div class="sc_call_to_action_descr sc_item_descr">' . trim(trueman_strmacros($description)) . '</div>' : '')
					. ($style==1 ? $buttons : '')
				. '</div>'
				. ($style==2 && $align!='right' ? $buttons : '')
				. ($need_columns ? '</div>' : '')
			. '</div>';
	
		return apply_filters('trueman_shortcode_output', $output, 'trx_call_to_action', $atts, $content);
	}
	trueman_require_shortcode('trx_call_to_action', 'trueman_sc_call_to_action');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_call_to_action_reg_shortcodes' ) ) {
	//add_action('trueman_action_shortcodes_list', 'trueman_sc_call_to_action_reg_shortcodes');
	function trueman_sc_call_to_action_reg_shortcodes() {
	
		trueman_sc_map("trx_call_to_action", array(
			"title" => esc_html__("Call to action", 'trueman'),
			"desc" => wp_kses_data( __("Insert call to action block in your page (post)", 'trueman') ),
			"decorate" => true,
			"container" => true,
			"params" => array(
				"title" => array(
					"title" => esc_html__("Title", 'trueman'),
					"desc" => wp_kses_data( __("Title for the block", 'trueman') ),
					"value" => "",
					"type" => "text"
				),
				"subtitle" => array(
					"title" => esc_html__("Subtitle", 'trueman'),
					"desc" => wp_kses_data( __("Subtitle for the block", 'trueman') ),
					"value" => "",
					"type" => "text"
				),
				"description" => array(
					"title" => esc_html__("Description", 'trueman'),
					"desc" => wp_kses_data( __("Short description for the block", 'trueman') ),
					"value" => "",
					"type" => "textarea"
				),
				"style" => array(
					"title" => esc_html__("Style", 'trueman'),
					"desc" => wp_kses_data( __("Select style to display block", 'trueman') ),
					"value" => "1",
					"type" => "checklist",
					"options" => trueman_get_list_styles(1, 2)
				),
				"align" => array(
					"title" => esc_html__("Alignment", 'trueman'),
					"desc" => wp_kses_data( __("Alignment elements in the block", 'trueman') ),
					"value" => "",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => trueman_get_sc_param('align')
				),
				"accent" => array(
					"title" => esc_html__("Accented", 'trueman'),
					"desc" => wp_kses_data( __("Fill entire block with links color from current color scheme", 'trueman') ),
					"divider" => true,
					"value" => "no",
					"type" => "switch",
					"options" => trueman_get_sc_param('yes_no')
				),
				"custom" => array(
					"title" => esc_html__("Custom", 'trueman'),
					"desc" => wp_kses_data( __("Allow get featured image or video from inner shortcodes (custom) or get it from shortcode parameters below", 'trueman') ),
					"divider" => true,
					"value" => "no",
					"type" => "switch",
					"options" => trueman_get_sc_param('yes_no')
				),
				"image" => array(
					"title" => esc_html__("Image", 'trueman'),
					"desc" => wp_kses_data( __("Select or upload image or write URL from other site to include image into this block", 'trueman') ),
					"divider" => true,
					"readonly" => false,
					"value" => "",
					"type" => "media"
				),
				"video" => array(
					"title" => esc_html__("URL for video file", 'trueman'),
					"desc" => wp_kses_data( __("Select video from media library or paste URL for video file from other site to include video into this block", 'trueman') ),
					"readonly" => false,
					"value" => "",
					"type" => "media",
					"before" => array(
						'title' => esc_html__('Choose video', 'trueman'),
						'action' => 'media_upload',
						'type' => 'video',
						'multiple' => false,
						'linked_field' => '',
						'captions' => array( 	
							'choose' => esc_html__('Choose video file', 'trueman'),
							'update' => esc_html__('Select video file', 'trueman')
						)
					),
					"after" => array(
						'icon' => 'icon-cancel',
						'action' => 'media_reset'
					)
				),
				"link" => array(
					"title" => esc_html__("Button URL", 'trueman'),
					"desc" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trueman') ),
					"divider" => true,
					"value" => "",
					"type" => "text"
				),
				"link_caption" => array(
					"title" => esc_html__("Button caption", 'trueman'),
					"desc" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trueman') ),
					"value" => "",
					"type" => "text"
				),
				"link2" => array(
					"title" => esc_html__("Button 2 URL", 'trueman'),
					"desc" => wp_kses_data( __("Link URL for the second button at the bottom of the block", 'trueman') ),
					"divider" => true,
					"value" => "",
					"type" => "text"
				),
				"link2_caption" => array(
					"title" => esc_html__("Button 2 caption", 'trueman'),
					"desc" => wp_kses_data( __("Caption for the second button at the bottom of the block", 'trueman') ),
					"value" => "",
					"type" => "text"
				),
				"width" => trueman_shortcodes_width(),
				"height" => trueman_shortcodes_height(),
				"top" => trueman_get_sc_param('top'),
				"bottom" => trueman_get_sc_param('bottom'),
				"left" => trueman_get_sc_param('left'),
				"right" => trueman_get_sc_param('right'),
				"id" => trueman_get_sc_param('id'),
				"class" => trueman_get_sc_param('class'),
				"animation" => trueman_get_sc_param('animation'),
				"css" => trueman_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_call_to_action_reg_shortcodes_vc' ) ) {
	//add_action('trueman_action_shortcodes_list_vc', 'trueman_sc_call_to_action_reg_shortcodes_vc');
	function trueman_sc_call_to_action_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_call_to_action",
			"name" => esc_html__("Call to Action", 'trueman'),
			"description" => wp_kses_data( __("Insert call to action block in your page (post)", 'trueman') ),
			"category" => esc_html__('Content', 'trueman'),
			'icon' => 'icon_trx_call_to_action',
			"class" => "trx_sc_collection trx_sc_call_to_action",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "style",
					"heading" => esc_html__("Block's style", 'trueman'),
					"description" => wp_kses_data( __("Select style to display this block", 'trueman') ),
					"class" => "",
					"admin_label" => true,
					"value" => array_flip(trueman_get_list_styles(1, 2)),
					"type" => "dropdown"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'trueman'),
					"description" => wp_kses_data( __("Select block alignment", 'trueman') ),
					"class" => "",
					"value" => array_flip(trueman_get_sc_param('align')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "accent",
					"heading" => esc_html__("Accent", 'trueman'),
					"description" => wp_kses_data( __("Fill entire block with links color from current color scheme", 'trueman') ),
					"class" => "",
					"value" => array("Fill with links color" => "yes" ),
					"type" => "checkbox"
				),
				array(
					"param_name" => "custom",
					"heading" => esc_html__("Custom", 'trueman'),
					"description" => wp_kses_data( __("Allow get featured image or video from inner shortcodes (custom) or get it from shortcode parameters below", 'trueman') ),
					"class" => "",
					"value" => array("Custom content" => "yes" ),
					"type" => "checkbox"
				),
				array(
					"param_name" => "image",
					"heading" => esc_html__("Image", 'trueman'),
					"description" => wp_kses_data( __("Image to display inside block", 'trueman') ),
					'dependency' => array(
						'element' => 'custom',
						'is_empty' => true
					),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "attach_image"
				),
				array(
					"param_name" => "video",
					"heading" => esc_html__("URL for video file", 'trueman'),
					"description" => wp_kses_data( __("Paste URL for video file to display inside block", 'trueman') ),
					'dependency' => array(
						'element' => 'custom',
						'is_empty' => true
					),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title", 'trueman'),
					"description" => wp_kses_data( __("Title for the block", 'trueman') ),
					"admin_label" => true,
					"group" => esc_html__('Captions', 'trueman'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "subtitle",
					"heading" => esc_html__("Subtitle", 'trueman'),
					"description" => wp_kses_data( __("Subtitle for the block", 'trueman') ),
					"group" => esc_html__('Captions', 'trueman'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "description",
					"heading" => esc_html__("Description", 'trueman'),
					"description" => wp_kses_data( __("Description for the block", 'trueman') ),
					"group" => esc_html__('Captions', 'trueman'),
					"class" => "",
					"value" => "",
					"type" => "textarea"
				),
				array(
					"param_name" => "link",
					"heading" => esc_html__("Button URL", 'trueman'),
					"description" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trueman') ),
					"group" => esc_html__('Captions', 'trueman'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "link_caption",
					"heading" => esc_html__("Button caption", 'trueman'),
					"description" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trueman') ),
					"group" => esc_html__('Captions', 'trueman'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "link2",
					"heading" => esc_html__("Button 2 URL", 'trueman'),
					"description" => wp_kses_data( __("Link URL for the second button at the bottom of the block", 'trueman') ),
					"group" => esc_html__('Captions', 'trueman'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "link2_caption",
					"heading" => esc_html__("Button 2 caption", 'trueman'),
					"description" => wp_kses_data( __("Caption for the second button at the bottom of the block", 'trueman') ),
					"group" => esc_html__('Captions', 'trueman'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				trueman_get_vc_param('id'),
				trueman_get_vc_param('class'),
				trueman_get_vc_param('animation'),
				trueman_get_vc_param('css'),
				trueman_vc_width(),
				trueman_vc_height(),
				trueman_get_vc_param('margin_top'),
				trueman_get_vc_param('margin_bottom'),
				trueman_get_vc_param('margin_left'),
				trueman_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Call_To_Action extends TRUEMAN_VC_ShortCodeCollection {}
	}
}
?>