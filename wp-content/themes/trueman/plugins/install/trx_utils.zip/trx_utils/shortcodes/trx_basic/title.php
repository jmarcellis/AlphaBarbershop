<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('trueman_sc_title_theme_setup')) {
	add_action( 'trueman_action_before_init_theme', 'trueman_sc_title_theme_setup' );
	function trueman_sc_title_theme_setup() {
		add_action('trueman_action_shortcodes_list', 		'trueman_sc_title_reg_shortcodes');
		if (function_exists('trueman_exists_visual_composer') && trueman_exists_visual_composer())
			add_action('trueman_action_shortcodes_list_vc','trueman_sc_title_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_title id="unique_id" style='regular|iconed' icon='' image='' background="on|off" type="1-6"]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_title]
*/

if (!function_exists('trueman_sc_title')) {	
	function trueman_sc_title($atts, $content=null){	
		if (trueman_in_shortcode_blogger()) return '';
		extract(trueman_html_decode(shortcode_atts(array(
			// Individual params
			"type" => "1",
			"style" => "regular",
			"align" => "",
			"font_weight" => "",
			"font_size" => "",
			"color" => "",
			"icon" => "",
			"image" => "",
			"picture" => "",
			"image_size" => "small",
			"position" => "left",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"width" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . trueman_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= trueman_get_css_dimensions_from_values($width)
			.($align && $align!='none' && !trueman_param_is_inherit($align) ? 'text-align:' . esc_attr($align) .';' : '')
			.($color ? 'color:' . esc_attr($color) .';' : '')
			.($font_weight && !trueman_param_is_inherit($font_weight) ? 'font-weight:' . esc_attr($font_weight) .';' : '')
			.($font_size   ? 'font-size:' . esc_attr($font_size) .';' : '')
			;
		$type = min(6, max(1, $type));
		if ($picture > 0) {
			$attach = wp_get_attachment_image_src( $picture, 'full' );
			if (isset($attach[0]) && $attach[0]!='')
				$picture = $attach[0];
		}
		$pic = $style!='iconed'
			? ''
			: '<span class="sc_title_icon sc_title_icon_'.esc_attr($position).'  sc_title_icon_'.esc_attr($image_size).($icon!='' && $icon!='none' ? ' '.esc_attr($icon) : '').'"'.'>'
				.($picture ? '<img src="'.esc_url($picture).'" alt="" />' : '')
				.(empty($picture) && $image && $image!='none' ? '<img src="'.esc_url(trueman_strpos($image, 'http:')!==false ? $image : trueman_get_file_url('images/icons/'.($image).'.png')).'" alt="" />' : '')
				.'</span>';
		$output = '<h' . esc_attr($type) . ($id ? ' id="'.esc_attr($id).'"' : '')
				. ' class="sc_title sc_title_'.esc_attr($style)
					.($align && $align!='none' && !trueman_param_is_inherit($align) ? ' sc_align_' . esc_attr($align) : '')
					.(!empty($class) ? ' '.esc_attr($class) : '')
					.'"'
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
				. (!trueman_param_is_off($animation) ? ' data-animation="'.esc_attr(trueman_get_animation_classes($animation)).'"' : '')
				. '>'

					. ($style=='divider' ? '<span class="sc_title_divider_before"'.($color ? ' style="background-color: '.esc_attr($color).'"' : '').'></span>' : '')
					. do_shortcode($content) 
					. ($style=='divider' ? '<span class="sc_title_divider_after"'.($color ? ' style="background-color: '.esc_attr($color).'"' : '').'></span>' : '')
                    . ($pic)
				. '</h' . esc_attr($type) . '>';
		return apply_filters('trueman_shortcode_output', $output, 'trx_title', $atts, $content);
	}
	trueman_require_shortcode('trx_title', 'trueman_sc_title');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_title_reg_shortcodes' ) ) {
	//add_action('trueman_action_shortcodes_list', 'trueman_sc_title_reg_shortcodes');
	function trueman_sc_title_reg_shortcodes() {
	
		trueman_sc_map("trx_title", array(
			"title" => esc_html__("Title", 'trx_utils'),
			"desc" => wp_kses_data( __("Create header tag (1-6 level) with many styles", 'trx_utils') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"_content_" => array(
					"title" => esc_html__("Title content", 'trx_utils'),
					"desc" => wp_kses_data( __("Title content", 'trx_utils') ),
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"type" => array(
					"title" => esc_html__("Title type", 'trx_utils'),
					"desc" => wp_kses_data( __("Title type (header level)", 'trx_utils') ),
					"divider" => true,
					"value" => "1",
					"type" => "select",
					"options" => array(
						'1' => esc_html__('Header 1', 'trueman'),
						'2' => esc_html__('Header 2', 'trueman'),
						'3' => esc_html__('Header 3', 'trueman'),
						'4' => esc_html__('Header 4', 'trueman'),
						'5' => esc_html__('Header 5', 'trueman'),
						'6' => esc_html__('Header 6', 'trueman'),
					)
				),
				"style" => array(
					"title" => esc_html__("Title style", 'trueman'),
					"desc" => wp_kses_data( __("Title style", 'trueman') ),
					"value" => "regular",
					"type" => "select",
					"options" => array(
						'regular' => esc_html__('Regular', 'trueman'),
						'underline' => esc_html__('Underline', 'trueman'),
						'divider' => esc_html__('Divider', 'trueman'),
						'iconed' => esc_html__('With icon (image)', 'trueman')
					)
				),
				"align" => array(
					"title" => esc_html__("Alignment", 'trueman'),
					"desc" => wp_kses_data( __("Title text alignment", 'trueman') ),
					"value" => "",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => trueman_get_sc_param('align')
				), 
				"font_size" => array(
					"title" => esc_html__("Font_size", 'trueman'),
					"desc" => wp_kses_data( __("Custom font size. If empty - use theme default", 'trueman') ),
					"value" => "",
					"type" => "text"
				),
				"font_weight" => array(
					"title" => esc_html__("Font weight", 'trueman'),
					"desc" => wp_kses_data( __("Custom font weight. If empty or inherit - use theme default", 'trueman') ),
					"value" => "",
					"type" => "select",
					"size" => "medium",
					"options" => array(
						'inherit' => esc_html__('Default', 'trueman'),
						'100' => esc_html__('Thin (100)', 'trueman'),
						'300' => esc_html__('Light (300)', 'trueman'),
						'400' => esc_html__('Normal (400)', 'trueman'),
						'600' => esc_html__('Semibold (600)', 'trueman'),
						'700' => esc_html__('Bold (700)', 'trueman'),
						'900' => esc_html__('Black (900)', 'trueman')
					)
				),
				"color" => array(
					"title" => esc_html__("Title color", 'trueman'),
					"desc" => wp_kses_data( __("Select color for the title", 'trueman') ),
					"value" => "",
					"type" => "color"
				),
				"icon" => array(
					"title" => esc_html__('Title font icon',  'trueman'),
					"desc" => wp_kses_data( __("Select font icon for the title from Fontello icons set (if style=iconed)",  'trueman') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "",
					"type" => "icons",
					"options" => trueman_get_sc_param('icons')
				),
				"image" => array(
					"title" => esc_html__('or image icon',  'trueman'),
					"desc" => wp_kses_data( __("Select image icon for the title instead icon above (if style=iconed)",  'trueman') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "",
					"type" => "images",
					"size" => "small",
					"options" => trueman_get_sc_param('images')
				),
				"picture" => array(
					"title" => esc_html__('or URL for image file', 'trueman'),
					"desc" => wp_kses_data( __("Select or upload image or write URL from other site (if style=iconed)", 'trueman') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"readonly" => false,
					"value" => "",
					"type" => "media"
				),
				"image_size" => array(
					"title" => esc_html__('Image (picture) size', 'trueman'),
					"desc" => wp_kses_data( __("Select image (picture) size (if style='iconed')", 'trueman') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "small",
					"type" => "checklist",
					"options" => array(
						'small' => esc_html__('Small', 'trueman'),
						'medium' => esc_html__('Medium', 'trueman'),
						'large' => esc_html__('Large', 'trueman')
					)
				),
				"position" => array(
					"title" => esc_html__('Icon (image) position', 'trueman'),
					"desc" => wp_kses_data( __("Select icon (image) position (if style=iconed)", 'trueman') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "left",
					"type" => "checklist",
					"options" => array(
						'bottom' => esc_html__('Bottom', 'trueman'),
						'left' => esc_html__('Left', 'trueman')
					)
				),
				"top" => trueman_get_sc_param('top'),
				"bottom" => trueman_get_sc_param('bottom'),
				"left" => trueman_get_sc_param('left'),
				"right" => trueman_get_sc_param('right'),
				"id" => trueman_get_sc_param('id'),
				"class" => trueman_get_sc_param('class'),
				"animation" => trueman_get_sc_param('animation'),
				"css" => trueman_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'trueman_sc_title_reg_shortcodes_vc' ) ) {
	//add_action('trueman_action_shortcodes_list_vc', 'trueman_sc_title_reg_shortcodes_vc');
	function trueman_sc_title_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_title",
			"name" => esc_html__("Title", 'trueman'),
			"description" => wp_kses_data( __("Create header tag (1-6 level) with many styles", 'trueman') ),
			"category" => esc_html__('Content', 'trueman'),
			'icon' => 'icon_trx_title',
			"class" => "trx_sc_single trx_sc_title",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "content",
					"heading" => esc_html__("Title content", 'trueman'),
					"description" => wp_kses_data( __("Title content", 'trueman') ),
					"class" => "",
					"value" => "",
					"type" => "textarea_html"
				),
				array(
					"param_name" => "type",
					"heading" => esc_html__("Title type", 'trueman'),
					"description" => wp_kses_data( __("Title type (header level)", 'trueman') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Header 1', 'trueman') => '1',
						esc_html__('Header 2', 'trueman') => '2',
						esc_html__('Header 3', 'trueman') => '3',
						esc_html__('Header 4', 'trueman') => '4',
						esc_html__('Header 5', 'trueman') => '5',
						esc_html__('Header 6', 'trueman') => '6'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "style",
					"heading" => esc_html__("Title style", 'trueman'),
					"description" => wp_kses_data( __("Title style: only text (regular) or with icon/image (iconed)", 'trueman') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Regular', 'trueman') => 'regular',
						esc_html__('Underline', 'trueman') => 'underline',
						esc_html__('Divider', 'trueman') => 'divider',
						esc_html__('With icon (image)', 'trueman') => 'iconed'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'trueman'),
					"description" => wp_kses_data( __("Title text alignment", 'trueman') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(trueman_get_sc_param('align')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "font_size",
					"heading" => esc_html__("Font size", 'trueman'),
					"description" => wp_kses_data( __("Custom font size. If empty - use theme default", 'trueman') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "font_weight",
					"heading" => esc_html__("Font weight", 'trueman'),
					"description" => wp_kses_data( __("Custom font weight. If empty or inherit - use theme default", 'trueman') ),
					"class" => "",
					"value" => array(
						esc_html__('Default', 'trueman') => 'inherit',
						esc_html__('Thin (100)', 'trueman') => '100',
						esc_html__('Light (300)', 'trueman') => '300',
						esc_html__('Normal (400)', 'trueman') => '400',
						esc_html__('Semibold (600)', 'trueman') => '600',
						esc_html__('Bold (700)', 'trueman') => '700',
						esc_html__('Black (900)', 'trueman') => '900'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "color",
					"heading" => esc_html__("Title color", 'trueman'),
					"description" => wp_kses_data( __("Select color for the title", 'trueman') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Title font icon", 'trueman'),
					"description" => wp_kses_data( __("Select font icon for the title from Fontello icons set (if style=iconed)", 'trueman') ),
					"class" => "",
					"group" => esc_html__('Icon &amp; Image', 'trueman'),
					'dependency' => array(
						'element' => 'style',
						'value' => array('iconed')
					),
					"value" => trueman_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "image",
					"heading" => esc_html__("or image icon", 'trueman'),
					"description" => wp_kses_data( __("Select image icon for the title instead icon above (if style=iconed)", 'trueman') ),
					"class" => "",
					"group" => esc_html__('Icon &amp; Image', 'trueman'),
					'dependency' => array(
						'element' => 'style',
						'value' => array('iconed')
					),
					"value" => trueman_get_sc_param('images'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "picture",
					"heading" => esc_html__("or select uploaded image", 'trueman'),
					"description" => wp_kses_data( __("Select or upload image or write URL from other site (if style=iconed)", 'trueman') ),
					"group" => esc_html__('Icon &amp; Image', 'trueman'),
					"class" => "",
					"value" => "",
					"type" => "attach_image"
				),
				array(
					"param_name" => "image_size",
					"heading" => esc_html__("Image (picture) size", 'trueman'),
					"description" => wp_kses_data( __("Select image (picture) size (if style=iconed)", 'trueman') ),
					"group" => esc_html__('Icon &amp; Image', 'trueman'),
					"class" => "",
					"value" => array(
						esc_html__('Small', 'trueman') => 'small',
						esc_html__('Medium', 'trueman') => 'medium',
						esc_html__('Large', 'trueman') => 'large'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "position",
					"heading" => esc_html__("Icon (image) position", 'trueman'),
					"description" => wp_kses_data( __("Select icon (image) position (if style=iconed)", 'trueman') ),
					"group" => esc_html__('Icon &amp; Image', 'trueman'),
					"class" => "",
					"std" => "left",
					"value" => array(
						esc_html__('Bottom', 'trueman') => 'bottom',
						esc_html__('Left', 'trueman') => 'left'
					),
					"type" => "dropdown"
				),
				trueman_get_vc_param('id'),
				trueman_get_vc_param('class'),
				trueman_get_vc_param('animation'),
				trueman_get_vc_param('css'),
				trueman_get_vc_param('margin_top'),
				trueman_get_vc_param('margin_bottom'),
				trueman_get_vc_param('margin_left'),
				trueman_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextView'
		) );
		
		class WPBakeryShortCode_Trx_Title extends TRUEMAN_VC_ShortCodeSingle {}
	}
}
?>